/**
 * Sliders Shortcode Generator
 *
 * WARNING: This file is part of the PrimaShop parent theme.
 * Please do all modifications in the form of a child theme.
 *
 * category   PrimaShop
 * package    Javascript
 * author     PrimaThemes
 * link       http://www.primathemes.com
 */
 
(
	function(){
	
		var url = '';
	
		tinymce.create(
			"tinymce.plugins.PrimaShortcodesSliders",
			{
				init: function(d,e) {
					url = e;
				},
				createControl:function(d,e)
				{
				
					if(d=="prima_shortcodes_sliders_button"){
					
						d=e.createMenuButton( "prima_shortcodes_sliders_button",{
							title: "Insert Sliders Shortcode",
							image: url + '/sliders.png',
							icons: false
							});
							
							var a=this;d.onRenderMenu.add(function(c,b){
								
								c=b.addMenu({title:"Posts Slider"});
									a.addImmediate(c,"Recent Posts",'[prima_slider_posts numbers="5" orderby="date" order="desc" image_width="600" image_height="300" post_title="yes" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Recent Posts (Thumbnail Navigation)",'[prima_slider_posts numbers="5" orderby="date" order="desc" image_width="600" image_height="300" post_title="yes" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="thumbnails"]<br/><br/>');
									a.addImmediate(c,"Recent Posts From A Category",'[prima_slider_posts category="Category Name" numbers="5" orderby="date" order="desc" image_width="600" image_height="300" post_title="yes" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Posts By IDs",'[prima_slider_posts ids="1,2,3" image_width="600" image_height="300" post_title="yes" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');

								c=b.addMenu({title:"Posts Carousel"});
									a.addImmediate(c,"Posts Carousel",'[prima_carousel_posts numbers="10" orderby="date" order="desc" image_width="150" image_height="150" post_title="yes" limit_content="120" min_items="2" max_items="4" move="1" animation="slide" speed="4000" duration="600" nav_direction="yes" ]<br/><br/>');
									a.addImmediate(c,"Posts Carousel From A Category",'[prima_carousel_posts category="Category Name" numbers="10" orderby="date" order="desc" image_width="150" image_height="150" post_title="yes" limit_content="120" min_items="2" max_items="4" move="1" animation="slide" speed="4000" duration="600" nav_direction="yes" ]<br/><br/>');
									a.addImmediate(c,"Posts Carousel By IDs",'[prima_carousel_posts ids="1,2,3" image_width="150" image_height="150" post_title="yes" limit_content="120" min_items="2" max_items="4" move="1" animation="slide" speed="4000" duration="600" nav_direction="yes" ]<br/><br/>');

								c=b.addMenu({title:"Posts Grid"});
									a.addImmediate(c,"Recent Posts",'[prima_grid_posts numbers="6" columns="3" orderby="date" order="desc" image_width="250" image_height="150" post_title="yes" limit_content="120" read_more=""]<br/><br/>');
									a.addImmediate(c,"Recent Posts From A Category",'[prima_grid_posts category="Category Name" numbers="6" orderby="date" order="desc" columns="3" image_width="250" image_height="150" post_title="yes" limit_content="120" read_more=""]<br/><br/>');

								c=b.addMenu({title:"Products Slider"});
									a.addImmediate(c,"Recent Products",'[prima_slider_products numbers="5" orderby="date" order="desc" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Recent Products From Category",'[prima_slider_products mode="category" orderby="date" order="desc" name="Category Name" numbers="5" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Recent Products From Tag",'[prima_slider_products mode="tag" name="Tag Name" numbers="5" orderby="date" order="desc" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Featured Products",'[prima_slider_products mode="featured" numbers="5" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Onsale Products",'[prima_slider_products mode="onsale" numbers="5" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Best Sellers Products",'[prima_slider_products mode="bestsellers" numbers="5" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Top Rated Products",'[prima_slider_products mode="toprated" numbers="5" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									a.addImmediate(c,"Products By IDs",'[prima_slider_products mode="ids" ids="1,2,3" image_width="400" image_height="300" product_saleflash="yes" product_price="yes" product_summary="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes" nav_control="yes"]<br/><br/>');
									
								c=b.addMenu({title:"Products Carousel"});
									a.addImmediate(c,"Recent Products",'[prima_carousel_products numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Recent Products From Category",'[prima_carousel_products mode="category" name="Category Name" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Recent Products From Tag",'[prima_carousel_products mode="tag" name="Tag Name" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Featured Products",'[prima_carousel_products mode="featured" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Onsale Products",'[prima_carousel_products mode="onsale" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Best Sellers Products",'[prima_carousel_products mode="bestsellers" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Top Rated Products",'[prima_carousel_products mode="toprated" numbers="10" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									a.addImmediate(c,"Products By IDs",'[prima_carousel_products mode="ids" ids="1,2,3" image_width="150" image_height="150"  min_items="2" max_items="4" move="1" product_saleflash="yes" product_title="yes" product_price="yes" product_button="yes" button_text="" animation="slide" speed="4000" duration="600" nav_direction="yes"]<br/><br/>');
									
							});
						return d
					
					} // End IF Statement
					
					return null
				},
		
				addImmediate:function(d,e,a){d.add({title:e,onclick:function(){
					var mce = typeof(tinymce) != 'undefined',
						wpActiveEditor = window.wpActiveEditor,
						ed;
					if ( ! wpActiveEditor ) {
						if ( mce && tinymce.activeEditor ) {
							ed = tinymce.activeEditor;
							wpActiveEditor = window.wpActiveEditor = ed.id;
						}
					}
					else if ( mce ) {
						if ( tinymce.activeEditor && (tinymce.activeEditor.id == 'mce_fullscreen' || tinymce.activeEditor.id == 'wp_mce_fullscreen') )
							ed = tinymce.activeEditor;
						else if ( tinymce.activeEditor && tinymce.activeEditor.id.indexOf("widget-black-studio") != "-1" )
							ed = tinymce.activeEditor;
						else
							ed = tinymce.get(wpActiveEditor);
					}
					if ( ed && !ed.isHidden() ) {
						ed.execCommand('mceInsertContent', false, a);
					} 
					else {
						document.getElementById(wpActiveEditor).value += a;
					}
				}})}
				
			}
		);
		
		tinymce.PluginManager.add( "PrimaShortcodesSliders", tinymce.plugins.PrimaShortcodesSliders);
	}
)();