<?php
/**
 * Setup theme specific admin functions
 *
 * WARNING: This file is part of the PrimaShop parent theme.
 * Please do all modifications in the form of a child theme.
 *
 * @category   PrimaShop
 * @package    Setup
 * @subpackage Admin
 * @author     PrimaThemes
 * @link       http://www.primathemes.com
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Check available theme update.
 *
 * @since PrimaShop 1.0.4
 */
add_action('prima-theme-settings-form-before', 'prima_theme_update_check');
function prima_theme_update_check() {
	$theme_name = 'PrimaShop (WC)';
	$template = 'primashop-wc';
	$allow_cache = true;

	if ( isset($_REQUEST['theme-updated']) && $_REQUEST['theme-updated'] == 'true' ) { 
		$allow_cache = false;
	}
	
	if ( !prima_get_setting('envato_username') || !prima_get_setting('envato_apikey') )
		return;
	
	include_once( trailingslashit(PRIMA_CUSTOM_DIR) . 'envato/class-envato-wordpress-theme-upgrader.php' );
	$prima_upgrader = new Prima_Envato_WordPress_Theme_Upgrader( prima_get_setting('envato_username'), prima_get_setting('envato_apikey') );
	$prima_update = $prima_upgrader->check_for_theme_update( $theme_name, $allow_cache );
	
	if ( $prima_update->updated_themes_count == 0 )
		return;
	
	$update = false;
	foreach ( $prima_update->updated_themes as $data ) {
		if ( $data->template == $template )
			$update = true;
	}
	
	if ( isset($_REQUEST['theme-updated']) && $_REQUEST['theme-updated'] == 'true' ) { 
		if ( $update ) {
			echo '<div id="message" class="error fade"><p><strong>';
			echo __('There was a problem updating the parent theme. Please Try again.', 'primathemes');
			echo '</strong></p></div>';
		}
		else {
			echo '<div id="message" class="updated fade"><p><strong>';
			echo __('Parent theme was successfully updated!', 'primathemes');
			echo '</strong></p></div>';
		}
	}
	
	if ( $update ) {
		$update_url = wp_nonce_url( add_query_arg( array( 'page' => 'primathemes', 'action' => 'update-theme' ), admin_url( 'themes.php' ) ), 'update-theme' );
		$update_onclick = 'onclick="if ( confirm(\'' . esc_js( __( "Updating the parent theme will lose any customizations you have made on the parent theme. 'Cancel' to stop, 'OK' to update.", 'primathemes' ) ) . '\') ) {return true;}return false;"';
		echo '<div id="message" class="updated fade"><p><strong>';
		echo __('There is a new version of the parent theme available.', 'primathemes').' <a href="'.$update_url.'" '.$update_onclick.'>'.__('Update automatically!', 'primathemes').'</a>';
		echo '</strong></p></div>';
	}
}

/**
 * Run theme update process.
 *
 * @since PrimaShop 1.0.4
 */
add_action('admin_init', 'prima_theme_update_run');
function prima_theme_update_run() {
	$theme_name = 'PrimaShop (WC)';
	$template = 'primashop-wc';
	$allow_cache = true;
	
    if ( !current_user_can( 'update_themes' ) )
		return;
	
	if ( !prima_get_setting('envato_username') || !prima_get_setting('envato_apikey') )
		return;
	
	if ( !isset($_REQUEST['page']) || $_REQUEST['page'] != 'primathemes' )
		return;
		
	if ( !isset($_REQUEST['action']) || $_REQUEST['action'] != 'update-theme')  
		return;
		
	check_admin_referer('update-theme');
	
	include_once( trailingslashit(PRIMA_CUSTOM_DIR) . 'envato/class-envato-wordpress-theme-upgrader.php' );
	$prima_upgrader = new Prima_Envato_WordPress_Theme_Upgrader( prima_get_setting('envato_username'), prima_get_setting('envato_apikey') );
	$result = $prima_upgrader->upgrade_theme( $theme_name, $allow_cache );
	
	wp_redirect( add_query_arg( array( 'page' => 'primathemes', 'theme-updated' => 'true' ), admin_url( 'themes.php' ) ) );
	exit;
}