/**
 * General Shortcode Generator
 *
 * WARNING: This file is part of the PrimaShop parent theme.
 * Please do all modifications in the form of a child theme.
 *
 * category   PrimaShop
 * package    Javascript
 * author     PrimaThemes
 * link       http://www.primathemes.com
 */
 
 (
	function(){
	
		var url = '';
	
		tinymce.create(
			"tinymce.plugins.PrimaShortcodesGeneral",
			{
				init: function(d,e) {
					url = e;
				},
				createControl:function(d,e)
				{
				
					if(d=="prima_shortcodes_general_button"){
					
						d=e.createMenuButton( "prima_shortcodes_general_button",{
							title: "Insert Shortcodes",
							image: url + '/general.png',
							icons: false
							});
							
							var a=this;d.onRenderMenu.add(function(c,b){
								
								c=b.addMenu({title:"Columns"});
									a.addImmediate(c,"2 Columns (1:1)","[column]<br/>[twocol_one] <br/><br/>First column content<br/><br/> [/twocol_one]<br/>[twocol_one_last]<br/><br/> Second column content<br/><br/> [/twocol_one_last]<br/>[/column]");
									a.addImmediate(c,"2 Columns (2:1)","[column]<br/>[threecol_two] <br/><br/>First column content<br/><br/> [/threecol_two]<br/>[threecol_one_last] <br/><br/>Second column content<br/><br/> [/threecol_one_last]<br/>[/column]");
									a.addImmediate(c,"2 Columns (1:2)","[column]<br/>[threecol_two] <br/><br/>First column content<br/><br/> [/threecol_two]<br/>[threecol_one_last] <br/><br/>Second column content<br/><br/> [/threecol_one_last]<br/>[/column]");
									a.addImmediate(c,"3 Columns (1:1:1)","[column]<br/>[threecol_one] <br/><br/>First column content<br/><br/> [/threecol_one]<br/>[threecol_one] <br/><br/>Second column content<br/><br/> [/threecol_one]<br/>[threecol_one_last] <br/><br/>Third column content<br/><br/> [/threecol_one_last]<br/>[/column]");
									a.addImmediate(c,"3 Columns (2:1:1)","[column]<br/>[fourcol_two] <br/><br/>First column content<br/><br/> [/fourcol_two]<br/>[fourcol_one] <br/><br/>Second column content<br/><br/> [/fourcol_one]<br/>[fourcol_one_last] <br/><br/>Third column content<br/><br/> [/fourcol_one_last]<br/>[/column]");
									a.addImmediate(c,"3 Columns (1:2:1)","[column]<br/>[fourcol_one] <br/><br/>First column content<br/><br/> [/fourcol_one]<br/>[fourcol_two] <br/><br/>Second column content<br/><br/> [/fourcol_two]<br/>[fourcol_one_last] <br/><br/>Third column content<br/><br/> [/fourcol_one_last]<br/>[/column]");
									a.addImmediate(c,"3 Columns (1:1:2)","[column]<br/>[fourcol_one] <br/><br/>First column content<br/><br/> [/fourcol_one]<br/>[fourcol_one] <br/><br/>Second column content<br/><br/> [/fourcol_one]<br/>[fourcol_two_last] <br/><br/>Third column content<br/><br/> [/fourcol_two_last]<br/>[/column]");
									a.addImmediate(c,"4 Columns","[column]<br/>[fourcol_one] <br/><br/>First column content<br/><br/> [/fourcol_one]<br/>[fourcol_one] <br/><br/>Second column content<br/><br/> [/fourcol_one]<br/>[fourcol_one] <br/><br/>Third column content<br/><br/> [/fourcol_one]<br/>[fourcol_one_last] <br/><br/>Fourth column content<br/><br/> [/fourcol_one_last]<br/>[/column]");
									a.addImmediate(c,"5 Columns","[column]<br/>[fivecol_one] <br/><br/>First column content<br/><br/> [/fivecol_one]<br/>[fivecol_one] <br/><br/>Second column content<br/><br/> [/fivecol_one]<br/>[fivecol_one] <br/><br/>Third column content<br/><br/> [/fivecol_one]<br/>[fivecol_one] <br/><br/>Fourth column content<br/><br/> [/fivecol_one]<br/>[fivecol_one_last] <br/><br/>Fifth column content<br/><br/> [/fivecol_one_last]<br/>[/column]");
									a.addImmediate(c,"6 Columns","[column]<br/>[sixcol_one] <br/><br/>First column content<br/><br/> [/sixcol_one]<br/>[sixcol_one] <br/><br/>Second column content<br/><br/> [/sixcol_one]<br/>[sixcol_one] <br/><br/>Third column content<br/><br/> [/sixcol_one]<br/>[sixcol_one] <br/><br/>Fourth column content<br/><br/> [/sixcol_one]<br/>[sixcol_one] <br/><br/>Fifth column content<br/><br/> [/sixcol_one]<br/>[sixcol_one_last] <br/><br/>Sixth column content<br/><br/> [/sixcol_one_last]<br/>[/column]");

								a.addImmediate(b,"Heading", "[heading]Your heading text[/heading]");

								c=b.addMenu({title:"Box"});
									a.addImmediate(c,"Simple Box","[box] Please insert your content here [/box]");
									a.addImmediate(c,"Blue Box","[box color=\"blue\"] Please insert your content here [/box]");
									a.addImmediate(c,"Red Blox","[box color=\"red\"] Please insert your content here [/box]");
									a.addImmediate(c,"Green Box","[box color=\"green\"] Please insert your content here [/box]");
									a.addImmediate(c,"Yellow Box","[box color=\"yellow\"] Please insert your content here [/box]");
									a.addImmediate(c,"Left Floated Box","[box float=\"left\"] Please insert your content here [/box]");
									a.addImmediate(c,"Right Floated Box","[box float=\"right\"] Please insert your content here [/box]");
								
								// b.addSeparator();
								
								c=b.addMenu({title:"Quote"});
									a.addImmediate(c,"Simple Quote","[quote] Please insert your content here [/quote]");
									a.addImmediate(c,"Left Floated Quote","[quote float=\"left\"] Please insert your content here [/quote]");
									a.addImmediate(c,"Right Floated Quote","[quote float=\"right\"] Please insert your content here [/quote]");
									a.addImmediate(c,"Boxed Quote","[quote style=\"boxed\"] Please insert your content here [/quote]");
									a.addImmediate(c,"Left Floated Boxed Quote","[quote style=\"boxed\" float=\"left\"] Please insert your content here [/quote]");
									a.addImmediate(c,"Right Floated Boxed Quote","[quote style=\"boxed\" float=\"right\"] Please insert your content here [/quote]");

								// b.addSeparator();
								
								c=b.addMenu({title:"Button"});
									a.addImmediate(c,"Simple Button","[button link=\"#\" ] Button Text [/button]");
									a.addImmediate(c,"Blue Button","[button link=\"#\" color=\"blue\"] Button Text [/button]");
									a.addImmediate(c,"Red Button","[button link=\"#\" color=\"red\"] Button Text [/button]");
									a.addImmediate(c,"Green Button","[button link=\"#\" color=\"green\"] Button Text [/button]");
									a.addImmediate(c,"Yellow Button","[button link=\"#\" color=\"yellow\"] Button Text [/button]");
									a.addImmediate(c,"Black Button","[button link=\"#\" color=\"black\"] Button Text [/button]");
								
								// b.addSeparator();
								
								c=b.addMenu({title:"Tabs"});
									a.addImmediate(c,"2 Tabs Content","[tabs]<br/>[tab title=\"First Tab\"]<br/><br/>First Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Second Tab\"]<br/><br/>Second Tab content goes here.<br/><br/>[/tab]<br/>[/tabs]");
									a.addImmediate(c,"3 Tabs Content","[tabs]<br/>[tab title=\"First Tab\"]<br/><br/>First Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Second Tab\"]<br/><br/>Second Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Third Tab\"]<br/><br/>Third Tab content goes here.<br/><br/>[/tab]<br/>[/tabs]");
									a.addImmediate(c,"4 Tabs Content","[tabs]<br/>[tab title=\"First Tab\"]<br/><br/>First Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Second Tab\"]<br/><br/>Second Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Third Tab\"]<br/><br/>Third Tab content goes here.<br/><br/>[/tab]<br/>[tab title=\"Fourth Tab\"]<br/><br/>Fourth Tab content goes here.<br/><br/>[/tab]<br/>[/tabs]");
								
								// b.addSeparator();
								
								a.addImmediate(b,"Toggle", "[toggle title=\"Toggle Title\"] <br/><br/>Please insert your content here<br/><br/> [/toggle]");
								a.addImmediate(b,"Dropcap", "[dropcap]T[/dropcap]his is an example of a dropcap text.");
								a.addImmediate(b,"Highlight", "You could edit this to put [highlight]important information[/highlight] on this page.");

								c=b.addMenu({title:"Media"});
									a.addImmediate(c,"Vimeo","[prima_vimeo id=\"30153918\" width=\"700\" height=\"386\"]");
									a.addImmediate(c,"Youtube","[prima_youtube id=\"chTkQgQKotA\" width=\"700\" height=\"386\"]");
								
								c=b.addMenu({title:"Contact Form"});
									a.addImmediate(c,"Contact Form (Simple)","[prima_contact_form email=\"\" subject=\"Message via the contact form\" button_text=\"Submit\"]");
									a.addImmediate(c,"Contact Form (Complete Options)","[prima_contact_form email=\"\" subject=\"Message via the contact form\" button_text=\"Submit\" sendcopy=\"yes\" question=\"What is bigger, 7 or 9?\" answer=\"9\"]");
								
								c=b.addMenu({title:"Google Map"});
									a.addImmediate(c,"Google Map (Roadmap)","[prima_googlemaps latitude=\"-37.82\" longitude=\"144.97\" zoom=\"15\" height=\"300\" type=\"roadmap\"]");
									a.addImmediate(c,"Google Map (Satellite)","[prima_googlemaps latitude=\"-37.82\" longitude=\"144.97\" zoom=\"15\" height=\"300\" type=\"satellite\"]");
									a.addImmediate(c,"Google Map (Hybrid)","[prima_googlemaps latitude=\"-37.82\" longitude=\"144.97\" zoom=\"15\" height=\"300\" type=\"hybrid\"]");
									a.addImmediate(c,"Google Map (Terrain)","[prima_googlemaps latitude=\"-37.82\" longitude=\"144.97\" zoom=\"15\" height=\"300\" type=\"terrain\"]");
								
							});
						return d
					
					} // End IF Statement
					
					return null
				},
				
				addImmediate:function(d,e,a){d.add({title:e,onclick:function(){
					var mce = typeof(tinymce) != 'undefined',
						wpActiveEditor = window.wpActiveEditor,
						ed;
					if ( ! wpActiveEditor ) {
						if ( mce && tinymce.activeEditor ) {
							ed = tinymce.activeEditor;
							wpActiveEditor = window.wpActiveEditor = ed.id;
						}
					}
					else if ( mce ) {
						if ( tinymce.activeEditor && (tinymce.activeEditor.id == 'mce_fullscreen' || tinymce.activeEditor.id == 'wp_mce_fullscreen') )
							ed = tinymce.activeEditor;
						else if ( tinymce.activeEditor && tinymce.activeEditor.id.indexOf("widget-black-studio") != "-1" )
							ed = tinymce.activeEditor;
						else
							ed = tinymce.get(wpActiveEditor);
					}
					if ( ed && !ed.isHidden() ) {
						ed.execCommand('mceInsertContent', false, a);
					} 
					else {
						document.getElementById(wpActiveEditor).value += a;
					}
				}})}
				
			}
		);
		
		tinymce.PluginManager.add( "PrimaShortcodesGeneral", tinymce.plugins.PrimaShortcodesGeneral);
	}
)();