<?php
/**
 * Setup plugin settings
 *
 * WARNING: This file is part of the PrimaShop parent theme.
 * Please do all modifications in the form of a child theme.
 *
 * @category   PrimaShop
 * @package    Setup
 * @subpackage Setting
 * @author     PrimaThemes
 * @link       http://www.primathemes.com
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add WooCommerce required plugin to Plugin Settings page.
 *
 * @since PrimaShop 1.1
 */
add_filter( 'prima_plugin_settings_args', 'prima_plugin_settings_args_woocommerce' );
function prima_plugin_settings_args_woocommerce( $plugins ) {

	$plugins[] = array(
			'name' 		=> 'WooCommerce',
			'slug' 		=> 'woocommerce',
			'required' 	=> true,
		);
		
	return $plugins;
}

/**
 * Add recommended plugins to Plugin Settings page.
 *
 * @since PrimaShop 1.1
 */
add_filter( 'prima_plugin_settings_args', 'prima_plugin_settings_args_recommended' );
function prima_plugin_settings_args_recommended( $plugins ) {

	$plugins[] = array(
			'name' 		=> 'Regenerate Thumbnails',
			'slug' 		=> 'regenerate-thumbnails',
			'required' 	=> false,
		);
		
	$plugins[] = array(
			'name' 		=> 'Codestyling Localization',
			'slug' 		=> 'codestyling-localization',
			'required' 	=> false,
		);
		
	$plugins[] = array(
			'name' 		=> 'WordPress SEO by Yoast',
			'slug' 		=> 'wordpress-seo',
			'required' 	=> false,
		);
		
	return $plugins;
}

/**
 * Add recommended YITH plugins to Plugin Settings page.
 *
 * @since PrimaShop 1.3
 */
add_filter( 'prima_plugin_settings_args', 'prima_plugin_settings_args_yith' );
function prima_plugin_settings_args_yith( $plugins ) {

	$plugins[] = array(
			'name' 		=> 'WooCommerce Zoom Magnifier by YITH',
			'slug' 		=> 'yith-woocommerce-zoom-magnifier',
			'required' 	=> false,
		);
		
	$plugins[] = array(
			'name' 		=> 'WooCommerce Wishlist by YITH',
			'slug' 		=> 'yith-woocommerce-wishlist',
			'required' 	=> false,
		);
		
	$plugins[] = array(
			'name' 		=> 'WooCommerce Compare by YITH',
			'slug' 		=> 'yith-woocommerce-compare',
			'required' 	=> false,
		);
		
	$plugins[] = array(
			'name' 		=> 'WooCommerce Ajax Search by YITH',
			'slug' 		=> 'yith-woocommerce-ajax-search',
			'required' 	=> false,
		);
		
	return $plugins;
}
