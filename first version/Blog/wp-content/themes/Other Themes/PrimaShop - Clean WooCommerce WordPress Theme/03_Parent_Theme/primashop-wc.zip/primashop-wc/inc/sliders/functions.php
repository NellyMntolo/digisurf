<?php
/**
 * Setup sliders specific functions
 *
 * WARNING: This file is part of the PrimaShop parent theme.
 * Please do all modifications in the form of a child theme.
 *
 * @category   PrimaShop
 * @package    Sliders
 * @subpackage Function
 * @author     PrimaThemes
 * @link       http://www.primathemes.com
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Add sliders shortcode generator button to visual editor.
 *
 * @since PrimaShop 1.1
 */
add_action( 'init', 'prima_sliders_shortcode_add_button' );
function prima_sliders_shortcode_add_button() {
	if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) return;
	if ( get_user_option('rich_editing') == 'true') :
		add_filter('mce_external_plugins', 'prima_sliders_shortcode_add_tinymce_plugin');
		add_filter('mce_buttons', 'prima_sliders_shortcode_register_button');
	endif;
}

/**
 * Register sliders shortcode generator button.
 *
 * @since PrimaShop 1.1
 */
function prima_sliders_shortcode_register_button($buttons) {
	array_push($buttons, "prima_shortcodes_sliders_button");
	return $buttons;
}

/**
 * Register sliders shortcode generator javascript.
 *
 * @since PrimaShop 1.1
 */
function prima_sliders_shortcode_add_tinymce_plugin($plugin_array) {
	global $prima;
	$plugin_array['PrimaShortcodesSliders'] = PRIMA_CUSTOM_URI . '/sliders/sliders.sg.js';
	return $plugin_array;
}
