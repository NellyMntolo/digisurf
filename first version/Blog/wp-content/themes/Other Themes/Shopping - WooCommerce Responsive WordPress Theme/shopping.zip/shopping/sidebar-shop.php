<?php if (is_dynamic_sidebar( 'right-sidebar' )) {
	dynamic_sidebar( 'right-sidebar' );
} ?>