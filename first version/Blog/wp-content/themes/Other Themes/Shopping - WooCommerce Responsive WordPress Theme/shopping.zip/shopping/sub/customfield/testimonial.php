<p class="wpo_section">
    <?php $mb->the_field('address'); ?>
    <label>Address:</label>
    <input type="text" name="<?php $mb->the_name(); ?>" value="<?php $mb->the_value(); ?>" />
</p>